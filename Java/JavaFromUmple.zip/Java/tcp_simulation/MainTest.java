/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.32.1.6535.66c005ced modeling language!*/

package tcp_simulation;
import java.lang.Thread;

/**
 * mainTest class
 */
// line 448 "../../model.ump"
public class MainTest
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public MainTest()
  {}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {}

  // line 452 "../../model.ump"
   public static  void main(String [] args){
    Thread.currentThread().setUncaughtExceptionHandler(new UmpleExceptionHandler());
    Thread.setDefaultUncaughtExceptionHandler(new UmpleExceptionHandler());
    Tcp_Server server= new Tcp_Server();
    server.start();
    Tcp_Client client= new Tcp_Client();
    client.start();
  }

  public static class UmpleExceptionHandler implements Thread.UncaughtExceptionHandler
  {
    public void uncaughtException(Thread t, Throwable e)
    {
      translate(e);
      if(e.getCause()!=null)
      {
        translate(e.getCause());
      }
      e.printStackTrace();
    }
    public void translate(Throwable e)
    {
      java.util.List<StackTraceElement> result = new java.util.ArrayList<StackTraceElement>();
      StackTraceElement[] elements = e.getStackTrace();
      try
      {
        for(StackTraceElement element:elements)
        {
          String className = element.getClassName();
          String methodName = element.getMethodName();
          boolean methodFound = false;
          int index = className.lastIndexOf('.')+1;
          try {
            java.lang.reflect.Method query = this.getClass().getMethod(className.substring(index)+"_"+methodName,new Class[]{});
            UmpleSourceData sourceInformation = (UmpleSourceData)query.invoke(this,new Object[]{});
            for(int i=0;i<sourceInformation.size();++i)
            {
              // To compensate for any offsets caused by injected code we need to loop through the other references to this function
              //  and adjust the start / length of the function.
              int functionStart = sourceInformation.getJavaLine(i) + (("main".equals(methodName))?3:1);
              int functionEnd = functionStart + sourceInformation.getLength(i);
              int afterInjectionLines = 0;
              //  We can leverage the fact that all inject statements are added to the uncaught exception list 
              //   before the functions that they are within
              for (int j = 0; j < i; j++) {
                if (sourceInformation.getJavaLine(j) - 1 >= functionStart &&
                    sourceInformation.getJavaLine(j) - 1 <= functionEnd &&
                    sourceInformation.getJavaLine(j) - 1 <= element.getLineNumber()) {
                    // A before injection, +2 for the comments surrounding the injected code
                    if (sourceInformation.getJavaLine(j) - 1 == functionStart) {
                        functionStart += sourceInformation.getLength(j) + 2;
                        functionEnd += sourceInformation.getLength(j) + 2;
                    } else {
                        // An after injection
                        afterInjectionLines += sourceInformation.getLength(j) + 2;
                        functionEnd += sourceInformation.getLength(j) + 2;
                    }
                }
              }
              int distanceFromStart = element.getLineNumber() - functionStart - afterInjectionLines;
              if(distanceFromStart>=0&&distanceFromStart<=sourceInformation.getLength(i))
              {
                result.add(new StackTraceElement(element.getClassName(),element.getMethodName(),sourceInformation.getFileName(i),sourceInformation.getUmpleLine(i)+distanceFromStart));
                methodFound = true;
                break;
              }
            }
          }
          catch (Exception e2){}
          if(!methodFound)
          {
            result.add(element);
          }
        }
      }
      catch (Exception e1)
      {
        e1.printStackTrace();
      }
      e.setStackTrace(result.toArray(new StackTraceElement[0]));
    }
  //The following methods Map Java lines back to their original Umple file / line    
    public UmpleSourceData Tcp_sendData(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(104).setJavaLines(398).setLengths(8);}
    public UmpleSourceData Tcp_sendFin(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(115).setJavaLines(410).setLengths(3);}
    public UmpleSourceData Tcp_activeOpen(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(32).setJavaLines(139).setLengths(1);}
    public UmpleSourceData Tcp_sendSyn(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(85).setJavaLines(377).setLengths(3);}
    public UmpleSourceData Tcp_passiveClose(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(61).setJavaLines(319).setLengths(1);}
    public UmpleSourceData Tcp_sendAck(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(97).setJavaLines(391).setLengths(3);}
    public UmpleSourceData Tcp_data(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(57).setJavaLines(299).setLengths(1);}
    public UmpleSourceData Tcp_sendSynAck(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(91).setJavaLines(384).setLengths(3);}
    public UmpleSourceData Tcp_syn(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(36).setJavaLines(159).setLengths(1);}
    public UmpleSourceData Tcp_fin(){ return new UmpleSourceData().setFileNames("model.ump","model.ump","model.ump").setUmpleLines(55, 69, 73).setJavaLines(247, 253, 259).setLengths(1, 1, 1);}
    public UmpleSourceData Tcp_activeClose(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(56).setJavaLines(279).setLengths(1);}
    public UmpleSourceData Tcp_finAck(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(70).setJavaLines(339).setLengths(1);}
    public UmpleSourceData Tcp_synAck(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(49).setJavaLines(227).setLengths(1);}
    public UmpleSourceData Queue_1_release_semC(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(140).setJavaLines(75).setLengths(1);}
    public UmpleSourceData Queue_1_release_semS(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(152).setJavaLines(89).setLengths(1);}
    public UmpleSourceData Queue_1_acquire_semC(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(132).setJavaLines(66).setLengths(5);}
    public UmpleSourceData Queue_1_acquire_semS(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(144).setJavaLines(80).setLengths(5);}
    public UmpleSourceData Queue_Tcp_getMessage(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(175).setJavaLines(65).setLengths(4);}
    public UmpleSourceData Queue_Tcp_putMessage(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(166).setJavaLines(52).setLengths(5);}
    public UmpleSourceData Queue_Tcp_isEmptyMessage(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(182).setJavaLines(73).setLengths(3);}
    public UmpleSourceData Receiver_run(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(199).setJavaLines(49).setLengths(7);}
    public UmpleSourceData MySocket_send(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(236).setJavaLines(115).setLengths(2);}
    public UmpleSourceData MySocket_close(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(241).setJavaLines(121).setLengths(4);}
    public UmpleSourceData MySocket_connect(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(221).setJavaLines(97).setLengths(7);}
    public UmpleSourceData MyServerSocket_accept(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(264).setJavaLines(115).setLengths(11);}
    public UmpleSourceData Tcp_Client_run(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(299).setJavaLines(129).setLengths(40);}
    public UmpleSourceData Tcp_Server_serverStarted(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(430).setJavaLines(221).setLengths(1);}
    public UmpleSourceData Tcp_Server_run(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(363).setJavaLines(154).setLengths(63);}
    public UmpleSourceData Tcp_Server_stopListening(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(439).setJavaLines(235).setLengths(1);}
    public UmpleSourceData Tcp_Server_serverStopped(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(434).setJavaLines(226).setLengths(1);}
    public UmpleSourceData MainTest_main(){ return new UmpleSourceData().setFileNames("model.ump").setUmpleLines(451).setJavaLines(32).setLengths(4);}

  }
  public static class UmpleSourceData
  {
    String[] umpleFileNames;
    Integer[] umpleLines;
    Integer[] umpleJavaLines;
    Integer[] umpleLengths;
    
    public UmpleSourceData(){
    }
    public String getFileName(int i){
      return umpleFileNames[i];
    }
    public Integer getUmpleLine(int i){
      return umpleLines[i];
    }
    public Integer getJavaLine(int i){
      return umpleJavaLines[i];
    }
    public Integer getLength(int i){
      return umpleLengths[i];
    }
    public UmpleSourceData setFileNames(String... filenames){
      umpleFileNames = filenames;
      return this;
    }
    public UmpleSourceData setUmpleLines(Integer... umplelines){
      umpleLines = umplelines;
      return this;
    }
    public UmpleSourceData setJavaLines(Integer... javalines){
      umpleJavaLines = javalines;
      return this;
    }
    public UmpleSourceData setLengths(Integer... lengths){
      umpleLengths = lengths;
      return this;
    }
    public int size(){
      return umpleFileNames.length;
    }
  }
}