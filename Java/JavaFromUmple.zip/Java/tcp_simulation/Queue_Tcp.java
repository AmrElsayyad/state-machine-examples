/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.32.1.6535.66c005ced modeling language!*/

package tcp_simulation;
import java.lang.Thread;
import java.lang.InterruptedException;
import java.util.*;

// line 158 "../../model.ump"
public class Queue_Tcp
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Queue_Tcp Attributes
  private LinkedList<String> messages;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Queue_Tcp()
  {
    messages = new LinkedList<String>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setMessages(LinkedList<String> aMessages)
  {
    boolean wasSet = false;
    messages = aMessages;
    wasSet = true;
    return wasSet;
  }

  /**
   * LinkedList messages;
   */
  public LinkedList<String> getMessages()
  {
    return messages;
  }

  public void delete()
  {}

  // line 167 "../../model.ump"
   public synchronized  void putMessage(String var) throws InterruptedException{
    messages.add(var);
   notify();
   //String msg = (String)messages.getFirst();
   String msg = messages.element();
   System.out.println("send message: " +msg);
  }


  /**
   * Called by Receiver thread
   */
  // line 176 "../../model.ump"
   public synchronized  String getMessage() throws InterruptedException{
    while ( messages.size() == 0 ) 
      wait();
    String message =messages.remove();
    return (message);
  }

  // line 183 "../../model.ump"
   public Boolean isEmptyMessage(){
    if(messages.size() == 0)
      return true;
    return false;
  }


  public String toString()
  {
    return super.toString() + "["+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "messages" + "=" + (getMessages() != null ? !getMessages().equals(this)  ? getMessages().toString().replaceAll("  ","    ") : "this" : "null");
  }
}